module EquipmentsHelper
end
